/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import { useState, useEffect, useRef } from "react";
import { Link, useParams } from "react-router-dom";
import { Panel } from "primereact/panel";
import { Button } from "primereact/button";
import { Menu } from "primereact/menu";
import { Toolbar } from "primereact/toolbar";
import { Tag } from "primereact/tag";
import PageHeader from "./components/PageHeader";
import { MultiSelect } from "primereact/multiselect";
import { Chip } from "primereact/chip";
import { Card } from "primereact/card";

function AppointmentsPage({ data, unique_sources }) {
  const [selectedCities, setSelectedCities] = useState([]); // Seçilen Mission Countries
  // const { name } = useParams();
  const changeCountry = useRef(null);
  // const selected_source = name.replaceAll("-", " ").toUpperCase();

  const create_missions = data.map((a) => a.mission_country);
  let unique_missions = [...new Set(create_missions)];

  let countries = unique_sources.map((s) => ({
    label: s,
    value: s,
  }));

  let mission_countries = unique_missions.map((m) => ({
    label: m,
    value: m,
  }));

  const headerTemp = (opt) => {
    return (
      <div className="flex flex-row justify-content-start">
        <p>
          <i className="fa-solid fa-plane-departure"></i> {opt.source_country}
        </p>
        <p>
          <i className="fa-solid fa-plane-arrival"></i> {opt.mission_country}
        </p>
      </div>
    );
  };
  const footerTemplate = (opt) => {
    const className =
      "w-full flex flex-wrap align-items-center justify-content-end gap-3";
    if (opt.appointment_date !== null) {
      return (
        <div className={className}>
          <Button label="Follow" severity="secondary"></Button>
          <a
            className="p-button p-component p-button-primary"
            href={opt.book_now_link}
            target="_blank"
          >
            Randevu Al
          </a>
        </div>
      );
    } else {
      return (
        <div className={className}>
          <Button label="Follow" severity="secondary"></Button>
        </div>
      );
    }
  };

  // MultiSelect değişikliği
  const handleMissions = (e) => {
    setSelectedCities(e.value);
  };

  const handleRemove = (city) => {
    setSelectedCities((prev) => prev.filter((c) => c !== city));
  };

  const filteredAppointments = selectedCities.length
    ? data.filter((a) => selectedCities.includes(a.mission_country))
    : data;

  const ChipList = () => {
    return selectedCities?.map((city, key) => (
      <Chip
        key={key}
        label={city}
        removable
        onRemove={() => handleRemove(city)}
      />
    ));
  };

  const FilterArea = () => {
    return (
      <header>
        <form>
          <section className="flex justify-content-start">
            <div className="mr-2">
              <Button
                type="button"
                label="Change Source Country"
                className="mr-2"
                onClick={(event) => changeCountry.current.toggle(event)}
                aria-controls="popup_menu_left"
                aria-haspopup
                severity="primary"
              />
              <Menu
                model={countries}
                popup
                ref={changeCountry}
                id="popup_change_country"
              />
            </div>
            <div className="mr-2">
              <MultiSelect
                value={selectedCities}
                onChange={handleMissions}
                options={mission_countries}
                optionLabel="label"
                optionValue="value"
                placeholder="Select a Mission Country"
              />
            </div>
          </section>
        </form>
      </header>
    );
  };
  const ToolbarContent = () => <Toolbar start={FilterArea} />;
  const AppointmentsGrid = () => {
    return (
      <section className="container py-5">
        <div className="grid grid-gutter">
          {filteredAppointments?.map((a, key) => {
            const class_name =
              a.appointment_date !== null
                ? "success col-12 sm:col-6 md:col-4"
                : "failed col-12 sm:col-6 md:col-4";
            const lc = new Date(a.last_checked); // last_checked
            const lc_date =
              lc.getDate() + "." + lc.getMonth() + "." + lc.getFullYear();
            const lc_time = lc.getHours() + ":" + lc.getMinutes();
            const lc_full = lc_date + " " + lc_time;
            return (
              <div key={key} className={class_name}>
                <Card footer={() => footerTemplate(a)}>
                  <div className="row">
                    <p className="mr-3">
                      <i className="fa-solid fa-plane-departure mr-1"></i>{" "}
                      {a.source_country}
                    </p>
                    <p>
                      <i className="fa-solid fa-plane-arrival mr-1"></i>{" "}
                      {a.mission_country}
                    </p>
                  </div>
                  <div className="row categories">
                    <i className="fa-solid fa-passport"></i>

                    <div className="ctgry flex flex-column ml-2">
                      <p>{a.visa_category}</p>
                      {a.visa_subcategory && (
                        <p className="p-subcategory">{`(${a.visa_subcategory})`}</p>
                      )}
                    </div>
                  </div>

                  <div className="row">
                    <i className="fa-solid fa-location-dot"></i>
                    <p className="ml-2">{a.center_name}</p>
                  </div>

                  <div className="row">
                    {a.appointment_date !== null ? (
                      <p>
                        <i className="fa-solid fa-calendar-check mr-2"></i>
                        <Tag severity="success" value={a.appointment_date} />
                      </p>
                    ) : (
                      <p>
                        <i className="fa-solid fa-calendar-xmark mr-2"></i>
                        <Tag severity="danger" value="No Date" />
                      </p>
                    )}
                  </div>
                  <div className="row">
                    <h6 className="text-lg mr-2">Last Checked:</h6>
                    <Tag severity={"info"} value={lc_full} />
                  </div>
                </Card>
              </div>
            );
          })}
        </div>
      </section>
    );
  };

  return (
    <>
      <PageHeader title={"Appointments"} />
      <ToolbarContent />
      {selectedCities.length > 0 && (
        <Panel>
          <div className="flex flex-row flex-wrap full-width">
            <ChipList />
          </div>
        </Panel>
      )}
      <AppointmentsGrid />
    </>
  );
}

export default AppointmentsPage;
