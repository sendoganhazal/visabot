/* eslint-disable react/prop-types */
// eslint-disable-next-line no-unused-vars
function PageHeader({title}) {
    return ( 
        <section className="container page-header">
            <h1 className="text-6xl text-gray-900">{title}</h1>
        </section>
    );
}

export default PageHeader;