import logo from "../assets/Layer_1.svg";

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="flex flex-row align-item-center">
          <h6 className="text-xl">
            Visa Bot by <img src={logo} alt="Maarifa Lab Logo" />
          </h6>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
