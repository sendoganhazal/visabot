/* eslint-disable no-unused-vars */
import { useState, useEffect } from "react";
import { Panel } from "primereact/panel";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./layout";
import AppointmentsPage from "./AppointmentsPage";

function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true); // Yüklenme durumu
  const [error, setError] = useState(null); // Hata durumu
  const [sources, setSources] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await fetch(
          "https://api.schengenvisaappointments.com/api/visa-list/?format=json"
        ); // REST API URL
        if (!response.ok) {
          throw new Error("Veri alınamadı");
        }
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // setSources(unique_sources);
  }, []); // Boş dizi, sadece ilk render'da çalışır.
  let sourceC = data?.map((d) => d.source_country);
  let unique_sources = [...new Set(sourceC)];

  if (loading) return <p>Yükleniyor...</p>;
  if (error) return <p>Hata: {error}</p>;
  return (
    <Layout>
      <AppointmentsPage data={data} unique_sources={unique_sources}/>
    </Layout>
  );
}

export default App;
