/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */

import Footer from "./components/Footer";

function Layout({ children }) {
  return (
    <main>
      {/*Header */}
      {/*Other Sections*/}
       <section className="wrapper">{children}</section>
      {/*Footer */}
      <Footer />
    </main>
  );
}

export default Layout;
